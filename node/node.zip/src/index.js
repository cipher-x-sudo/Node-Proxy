const express = require('express');
const puppeteer = require('puppeteer');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const helmet = require('helmet');
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const config = require('./config');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

// Browser instance management
let browser = null;

async function initBrowser() {
    if (!browser) {
        browser = await puppeteer.launch({
            headless: 'new',
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--disable-gpu',
                '--window-size=1920x1080',
                '--disable-web-security',
                '--disable-features=IsolateOrigins,site-per-process',
                '--disable-site-isolation-trials'
            ],
            ignoreHTTPSErrors: true
        });
    }
    return browser;
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(cors({
    origin: `https://${config.proxyDomain}`,
    credentials: true
}));
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'", "https:"],
            scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", "https:"],
            fontSrc: ["'self'", "https:"],
            connectSrc: ["'self'", "https:"]
        }
    }
}));

// Load cookies from JSON file
let allowedCookies = [];
let cookies = {};

async function loadCookies() {
    try {
        const cookiesData = JSON.parse(await fs.readFile('cookies2.json', 'utf8'));
        allowedCookies = [...new Set(cookiesData.map(cookie => cookie.name))];
        cookies = cookiesData.reduce((acc, cookie) => {
            if (allowedCookies.includes(cookie.name)) {
                acc[cookie.name] = cookie.value;
            }
            return acc;
        }, {});
    } catch (error) {
        console.error('Error loading cookies:', error);
    }
}

// URL rewriting functions
function rewriteUrl(url, subdomain = '') {
    const urlObj = new URL(url);
    if (urlObj.hostname.endsWith(config.targetDomain)) {
        const subdomainPart = urlObj.hostname.split('.')[0];
        return url.replace(
            `${subdomainPart}.${config.targetDomain}`,
            `${config.proxyDomain}/${subdomainPart}${config.subdomainMarker}`
        );
    }
    return url;
}

function processHtml(html, subdomain = '') {
    const $ = cheerio.load(html);
    
    // Process tags
    config.tagsToOverride.forEach(tag => {
        $(tag).each((_, element) => {
            config.attributesToOverride.forEach(attr => {
                const value = $(element).attr(attr);
                if (value && value.includes(config.targetDomain)) {
                    $(element).attr(attr, rewriteUrl(value, subdomain));
                }
            });
        });
    });

    // Inject configuration and scripts
    $('head').append(`
        <script>
            window.proxyConfig = ${JSON.stringify(config)};
        </script>
        <script src="/assets/s1.js"></script>
        <script src="/assets/s2.js"></script>
    `);

    return $.html();
}

// Main proxy handler
app.all('*', async (req, res) => {
    try {
        // Extract subdomain from path
        const pathMatch = req.path.match(new RegExp(`^/([a-z0-9-]+)${config.subdomainMarker}(/.*)?$`, 'i'));
        const subdomain = pathMatch ? pathMatch[1] : '';
        const cleanPath = pathMatch ? (pathMatch[2] || '/') : req.path;
        
        // Build target URL
        const targetHost = subdomain ? `${subdomain}.${config.targetDomain}` : config.targetDomain;
        const targetUrl = `https://${targetHost}${cleanPath}${req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : ''}`;

        // Initialize browser if not already done
        const browser = await initBrowser();
        const page = await browser.newPage();

        // Set up page configuration
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        await page.setExtraHTTPHeaders({
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1'
        });

        // Set cookies
        const cookiesArray = Object.entries(cookies).map(([name, value]) => ({
            name,
            value,
            domain: targetHost,
            path: '/'
        }));
        await page.setCookie(...cookiesArray);

        // Navigate to the target URL
        const response = await page.goto(targetUrl, {
            waitUntil: 'networkidle0',
            timeout: 30000
        });

        // Get the final HTML content
        const body = await page.content();

        // Process response based on content type
        let processedBody = body;
        const contentType = response.headers()['content-type'] || '';
        
        if (contentType.includes('text/html')) {
            processedBody = processHtml(body, subdomain);
        } else if (contentType.includes('application/json')) {
            processedBody = body.replace(
                new RegExp(`https?://([a-z0-9-]+)\\.${config.targetDomain}(/[^"']+)`, 'gi'),
                (match, sub, path) => `https://${config.proxyDomain}/${sub}${config.subdomainMarker}${path}`
            );
        }

        // Set response headers
        res.set('Content-Type', contentType);
        const headers = response.headers();
        Object.entries(headers).forEach(([key, value]) => {
            if (!['content-encoding', 'content-length'].includes(key.toLowerCase())) {
                res.set(key, value);
            }
        });

        // Close the page
        await page.close();

        // Send response
        res.status(response.status()).send(processedBody);

    } catch (error) {
        console.error('Proxy error:', error);
        res.status(500).send('Internal Server Error');
    }
});

// Start server
async function startServer() {
    await loadCookies();
    await initBrowser();
    app.listen(port, () => {
        console.log(`Proxy server running on port ${port}`);
    });
}

// Handle graceful shutdown
process.on('SIGINT', async () => {
    if (browser) {
        await browser.close();
    }
    process.exit(0);
});

startServer(); 